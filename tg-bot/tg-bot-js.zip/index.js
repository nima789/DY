const http = require("http");
const { exec } = require("child_process");

const PORT = 8080;

// Creating a server instance
const server = http.createServer((req, res) => {
  // Set the response header
  res.writeHead(200, {'Content-Type': 'text/plain'});

  // Send the response
  res.end('Hello, World!\n');
});

server.listen(PORT, () => {
  console.log(`Server running at http://127.0.0.1:${PORT}/`);
  setInterval(keepWebAlive, 10 * 1000); // Start keeping web server alive check
});
function keepWebAlive() {
  exec("pgrep -laf bot-linux-amd64", function (err, stdout, stderr) {
    if (stdout.includes("./bot-linux-amd64")) {
      // console.log("web is running");
    } else {
      exec("chmod 777 ./bot-linux-amd64 && ./bot-linux-amd64");
      console.log("web start");
    }
  });
}
