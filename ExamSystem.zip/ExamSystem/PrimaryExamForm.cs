﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PrimaryExamForm : Form
    {
        public PrimaryExamForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExamScore();
            timer1.Enabled = false;
            
        }

        private void ExamScore()
        {
            int score = 0;
            if (this.textBox1.Text == "2000") score = score + 10;
            if (this.radioButton1.Checked) score = score + 10;
            if (this.radioButton6.Checked) score = score + 10;
            if (this.listBox1.Text == "PasswordChar") score = score + 10;
            if (this.comboBox1.Text == "Text") score = score + 10;
            if (this.checkBox1.Checked && this.checkBox2.Checked && this.checkBox3.Checked && !this.checkBox4.Checked) score = score + 10;

            this.textBox3.Text = score.ToString();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        int ExamSecond = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {

            if (ExamSecond < 120)
            {
                ExamSecond++;
                this.textBox2.Text = ExamSecond.ToString();
                this.toolStripProgressBar1.Value = ExamSecond;
            }else
            {
                ExamScore();
            }
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void PrimaryExamForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show(this, "确定要退出考试吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                PrimaryExamForm PrFc = new PrimaryExamForm();
                PrFc.Close();
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
