﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CoverForm : Form
    {
        public CoverForm()
        {
            InitializeComponent();
        }

        private void 初级自测试题PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrimaryExamForm PFrm = new PrimaryExamForm();
            PFrm.Show();
        }

        private void 退出XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void 关于系统AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aForm = new AboutBox1();
            aForm.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripComboBox1_TextChanged(object sender, EventArgs e)
        {
            String sltltem = this.toolStripComboBox1.Text;
            switch (sltltem)
            {
                case ("初级考试试题"):
                    PrimaryExamForm PFrm = new PrimaryExamForm();
                    PFrm.Show();
                    break;
                case ("中级考试试题"):
                    break;
                case ("高级考试试题"):
                    break;
            }
        }

        private void 题型选择TToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
